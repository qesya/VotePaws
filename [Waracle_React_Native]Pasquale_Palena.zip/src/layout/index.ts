export { default as NormalLayout } from "./normal-layout";
