export { default } from "./CatImageDetails";
