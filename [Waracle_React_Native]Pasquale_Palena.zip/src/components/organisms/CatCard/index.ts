export { default } from "./CatCard";
export { default as ProductCardSkeleton } from "./CatCard.skeleton";
export type { CatCardProps } from "./CatCard.types";
