export { default } from "./Typography";
