export { default } from "./SkeletonBox";
